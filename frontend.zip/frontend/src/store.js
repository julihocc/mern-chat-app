// frontend/src/store.js

import { configureStore } from '@reduxjs/toolkit';
import userReducer from './reducers';

const rootReducer = {
    user: userReducer
    // other reducers can go here
};

const store = configureStore({
    reducer: rootReducer
});

export default store;
