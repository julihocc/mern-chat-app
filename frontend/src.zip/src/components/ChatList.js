// Path: frontend\src\components\dashboardUtils\ChatList.js
import React from 'react';
import { useQuery } from '@apollo/client';  // updated the import from '@apollo/react-hooks' to '@apollo/client'
import { Link } from "react-router-dom";
import { CircularProgress, Alert, List, ListItem, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";
import log from '../utils/logger';  // importing the logger
import {
    GET_CHAT_ROOMS,
    GET_USERS_BY_ID,
    GET_CURRENT_USER
} from '../gql/gqlHub';  // importing the query

const ChatRoom = ({ id, participantIds }) => {
    const { loading, error, data } = useQuery(GET_USERS_BY_ID, {
        variables: { userIds: participantIds },
    });

    const { loading: loadingCurrentUser, error: errorCurrentUser, data: dataCurrentUser } = useQuery(GET_CURRENT_USER, {
        fetchPolicy: 'network-only', // ignore cache
    });

    if (loading) return <CircularProgress />;
    if (error) {
        log.error(`Error when trying to get users by id: ${error.message}`);  // using logger
        return <Alert severity="error">Error: {error.message}</Alert>;
    }

    if (loadingCurrentUser) return <CircularProgress />;
    if (errorCurrentUser) {
        log.error(`Error when trying to get current user: ${errorCurrentUser.message}`);  // using logger
        return <Alert severity="error">Error: {errorCurrentUser.message}</Alert>;
    }

    return (
        <ListItem>
            <Link to={`/chat/${id}`}> Chat ID: {id}
                <List>
                    {data.getUsersById.map((user) => (
                        <ListItem key={user.id}>
                            {user.id === dataCurrentUser.getCurrentUser.id ? 'You' : user.username}
                        </ListItem>
                    ))}
                </List>
            </Link>

        </ListItem>
    );
};

const ChatList = () => {
    const {t} = useTranslation();
    const { loading, error, data } = useQuery(GET_CHAT_ROOMS, {
        fetchPolicy: 'network-only', // ignore cache
    });

    if (loading) return <CircularProgress />;
    if (error) {
        log.error(`Error when trying to get chat rooms: ${error.message}`);  // using logger
        return <Alert severity="error">Error: {error.message}</Alert>;
    }


    return (
        <div>
            <Typography variant="h3">{t('chatList')}</Typography>
            <List>
                {data.getChatRooms.map(({ id, participantIds }) => (
                    <ChatRoom key={id} id={id} participantIds={participantIds} />
                ))}
            </List>
        </div>
    );
};

export default ChatList;
