// path: frontend\src\App.js
import { BrowserRouter as Router } from 'react-router-dom';
import AuthProvider from "./AuthProvider";
import MainRoutes from "./MainRoutes";  // Import MainRoutes
import { Provider } from 'react-redux';
import store from './store';

function App() {
    return (
        <div className="App">
            <AuthProvider>
                <Router>
                    <Provider store={store}>
                        <MainRoutes />
                    </Provider>
                </Router>
            </AuthProvider>
        </div>
    );
}

export default App;
