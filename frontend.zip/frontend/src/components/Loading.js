// Loading.js
import React from 'react';

const Loading = ({ queryName }) => <p>{queryName} Loading...</p>;

export default Loading;
