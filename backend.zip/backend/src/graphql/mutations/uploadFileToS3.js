// backend/src/graphql/mutations/uploadFileToS3.js

const {uploadFile} = require("../../s3Service");

const uploadFileToS3 = async (parent, args, context) => {
    const { file, chatRoomId } = args;
    const { pubSub } = context;
    const uploadedFile = await uploadFile(file);
    pubSub.publish(`FILE_UPLOADED_${chatRoomId}`, { fileUploaded: uploadedFile });
    return uploadedFile;
}

module.exports = { uploadFileToS3 };
